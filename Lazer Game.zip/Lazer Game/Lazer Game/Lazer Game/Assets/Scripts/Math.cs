﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Math : MonoBehaviour
{
    ///public float[] values = { 0, 1, 2, 3, 4, 5 };
    int Sum1, Sum2, Sum3;
    public Text question;
    float RandomValue1;
    float RandomValue2;
    public GameObject digit;
    
    

    // Start is called before the first frame update
    void Start()
    {
        MathBehaviour();
        AnsOptions();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void AnsOptions()
    {
        string dig = digit.GetComponentInChildren<Text>().text;
        Debug.Log(dig);
    }

    void MathBehaviour()
    {
        int RandomValue1 = Random.Range(0, 6);
        Debug.Log("RV1 is" + RandomValue1);
        int RandomValue2 = Random.Range(0, 6);
        Debug.Log("RV2 is" + RandomValue2);
        int RandomValue3 = Random.Range(0, 6);
        Debug.Log("RV3 is" + RandomValue3);
        int RandomValue4 = Random.Range(0, 6);
        Debug.Log("RV4 is" + RandomValue4);
        int RandomValue5 = Random.Range(0, 6);
        Debug.Log("RV5 is" + RandomValue5);
        int RandomValue6 = Random.Range(0, 6);
        Debug.Log("RV6 is" + RandomValue6);
        Sum1 = RandomValue1 + RandomValue2;
        Debug.Log("Sum1 is" + Sum1);
        Sum2 = RandomValue3 + RandomValue4;
        Debug.Log("Sum2 is" + Sum2);
        Sum3 = RandomValue5 + RandomValue6;
        Debug.Log("Sum3 is" + Sum3);

        float[] sums = { Sum1, Sum2, Sum3 };
        float randsum = sums[Random.Range(0, sums.Length)];
        //Debug.Log(randsum);
        //digit.text = randsum.ToString();
        question.text = RandomValue1 + " + " + RandomValue2;
    }
}
