﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour {
    public GameObject enemyPrefab;
    public float width = 10f;
    public float height = 10f;
    private bool movingRight = true;
    public float speed = 5.0f;
    public float spawnDelay = 0.5f;
    public GameObject winPanel;
    private float xmax;
    private float xmin;

	// Use this for initialization
	void Start () {
        float distanceToCamera = transform.position.z - Camera.main.transform.position.z;
        Vector3 leftBoundary = Camera.main.ViewportToWorldPoint(new Vector3(0, 0, distanceToCamera));
        Vector3 RightBoundary = Camera.main.ViewportToWorldPoint(new Vector3(1, 0, distanceToCamera));

        xmax = RightBoundary.x;
        xmin = leftBoundary.x;

        SpawnUntilFull();

        winPanel.SetActive(false);
    }
	
    public void OnDrawGizmos()
    {
        Gizmos.DrawWireCube(transform.position, new Vector3(width, height));
    }
	// Update is called once per frame
	void Update () {
        if (movingRight)
        {
            transform.position += Vector3.right * speed * Time.deltaTime;
        }
        else
        {
            transform.position += Vector3.left * speed * Time.deltaTime;
        }

        float RightEdgeofFormation = transform.position.x + (0.5f * width);
        float LeftEdgeofFormation = transform.position.x - (0.5f * width);
        if (LeftEdgeofFormation < xmin )
        {
            movingRight = true;
        }
        else if(RightEdgeofFormation > xmax)
        {
            movingRight = false;
        }

        if (AllMembersDead())
        {
            winPanel.SetActive(true);
            //SpawnUntilFull();
        }
    }

    Transform NextFreePosition()
    {
        foreach(Transform childPositionGameObject in transform)
        {
            if (childPositionGameObject.childCount == 0)
            {
                return childPositionGameObject;
            }
        }

        return null;
    }

    bool AllMembersDead()
    {
        foreach(Transform childPositionGameObject in transform)
        {
            if (childPositionGameObject.childCount > 0)
            {
                return false;
            }
           
        }
        return true;
    }

    void SpawnEnemies()
    {
        Transform digit;
        foreach (Transform child in transform)
        {
            GameObject enemy = Instantiate(enemyPrefab, child.transform.position, Quaternion.identity) as GameObject;
            enemy.transform.parent = child;
            digit = enemy.transform.Find("Digit");
            Debug.Log("Found");
            //enemy.GetComponentInChildren<TextMesh>().text;
        }
    }

    void SpawnUntilFull()
    {
        Transform freePosition = NextFreePosition();
        if (freePosition)
        {
            GameObject enemy = Instantiate(enemyPrefab, freePosition.position, Quaternion.identity) as GameObject;
            enemy.transform.parent = freePosition;
        }

        if (NextFreePosition())
        {
            Invoke("SpawnUntilFull", spawnDelay);
        }

    }
}
