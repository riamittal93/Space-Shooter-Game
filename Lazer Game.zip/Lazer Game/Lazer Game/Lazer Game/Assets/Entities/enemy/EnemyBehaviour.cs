﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyBehaviour : MonoBehaviour {
    public GameObject EnemyProjectile;
    public float health = 150f;
    public float ProjectileSpeed = 5f;
    public float ShotsPerSecond = 2f;
    public int scoreValue = 150;
    private Scorekeeper scoreKeeper;
    private Text Digit; 

    void Start()
    {
        scoreKeeper = GameObject.Find("Score").GetComponent<Scorekeeper>();
       // Digit = GameObject.Find("Digit").GetComponent<Text>();

    }
    void Update()
    {
        float probability = Time.deltaTime * ShotsPerSecond;
        float rand = Random.value;
        if (rand < probability)
        {
          Fire();
        }


    }

    void Fire()
    {
        
        Vector3 startPosition = transform.position + new Vector3(0, -1f, 0);
        GameObject missile = Instantiate(EnemyProjectile, startPosition, Quaternion.identity) as GameObject;
        missile.GetComponent<Rigidbody2D>().velocity = new Vector2(0, -ProjectileSpeed);
    }
	void OnTriggerEnter2D(Collider2D collider)
    {
        Projectile missile =  collider.gameObject.GetComponent<Projectile>();

        if (missile)
        {
            health -= missile.GetDamage();
            missile.Hit();
            if (health <= 0)
            {
                Destroy(gameObject);
                scoreKeeper.Score(scoreValue);
            }

        }
    }
}
